/** Select historical source blobs that the committed checkout cannot reconstruct exactly. */
import { readFile, readdir, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve, join, relative, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const directory = dirname(fileURLToPath(import.meta.url));
const archive = resolve(process.argv[2] ?? join(directory, "rising"));
const repository = resolve(process.argv[3] ?? process.cwd());
const trackedRecord = JSON.parse(await readFile(join(directory, "tracked-source.json"), "utf8"));
const tracked = new Set(trackedRecord.files);
const digest = bytes => createHash("sha256").update(bytes).digest("hex");
const wanted = new Map(), referencedBy = new Map(), required = new Set(), dataFiles = [];
const scan = (value, record) => {
  if (!value || typeof value !== "object") return;
  if (value.implementation && typeof value.implementation === "object") for (const [path, hash] of Object.entries(value.implementation)) {
    if (!/^[0-9a-f]{64}$/.test(hash) || path.startsWith("/") || /[\\:]/.test(path) || path.split("/").some(p => !p || p === "." || p === ".."))
      throw new Error(`invalid archived implementation entry: ${path}`);
    const paths = wanted.get(hash) ?? new Set(); paths.add(path); wanted.set(hash, paths);
    const records = referencedBy.get(hash) ?? new Set(); records.add(record); referencedBy.set(hash, records);
  }
  for (const child of Object.values(value)) if (child && typeof child === "object") scan(child, record);
};
const walk = async path => {
  for (const entry of await readdir(path, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error(`link in archive: ${entry.name}`);
    if (["source", "runtime", "verify-runtime"].includes(entry.name) || entry.name.startsWith("materializer-check") || entry.name === "archive.mjs") continue;
    const full = join(path, entry.name);
    if (entry.isDirectory()) await walk(full);
    else {
      dataFiles.push(relative(archive, full).replaceAll("\\", "/"));
      if (entry.name.endsWith(".json")) {
        const record = JSON.parse(await readFile(full, "utf8"));
        if (path === archive && ["warrior.json", "rogue.json"].includes(entry.name))
          for (const hash of Object.values(record.implementation)) required.add(hash);
        scan(record, relative(archive, full).replaceAll("\\", "/"));
      }
    }
  }
};
await walk(archive);
const blobs = [], reused = [], missingHistoricalSources = [];
for (const [hash, paths] of wanted) {
  let from = null;
  for (const path of paths) {
    if (!tracked.has(path)) continue;
    try {
      const bytes = await readFile(join(repository, path));
      const variants = [bytes];
      if (/\.(ts|mjs|js|json)$/.test(path)) {
        const lf = bytes.toString().replaceAll("\r\n", "\n");
        variants.push(Buffer.from(lf), Buffer.from(lf.replaceAll("\n", "\r\n")));
      }
      if (variants.some(bytes => digest(bytes) === hash)) { from = path; break; }
    } catch (error) { if (error.code !== "ENOENT") throw error; }
  }
  if (from) reused.push({ hash, path: from });
  else {
    let bytes;
    try { bytes = await readFile(join(archive, "source", hash)); }
    catch (error) {
      if (error.code !== "ENOENT" || required.has(hash)) throw error;
      missingHistoricalSources.push({ hash, sources: [...paths], records: [...referencedBy.get(hash)] }); continue;
    }
    if (digest(bytes) !== hash) throw new Error(`corrupt source blob ${hash}`);
    blobs.push({ path: `source/${hash}`, bytes: bytes.length, sources: [...paths] });
  }
}
const result = { repositoryCommit: trackedRecord.commit,
  dataFiles: dataFiles.sort(), blobs, reused, missingHistoricalSources,
  activeCheckpointSourceHashes: required.size, blobBytes: blobs.reduce((sum, file) => sum + file.bytes, 0) };
await writeFile(join(directory, "portable-manifest.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify({ dataFiles: result.dataFiles.length, historicalBlobs: blobs.length, historicalBlobBytes: result.blobBytes,
  reconstructedFromCheckout: reused.length, missingHistoricalSources: missingHistoricalSources.length,
  activeCheckpointSourceHashes: required.size, output: join(directory, "portable-manifest.json") }));

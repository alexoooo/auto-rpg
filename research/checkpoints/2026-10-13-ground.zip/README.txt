Rising experiment handoff

Keep this artifact directory inside the Auto-RPG checkout on the receiving computer.
Use Node 24.15.0 and run npm ci in that checkout. Do not run two processes writing the
same search checkpoint. A live checkpoint must be stopped before copying it.

Extract research/checkpoints/2026-10-13-ground.zip into this artifact directory.
The rising directory needs each unfinished search's .json checkpoint, its .jsonl
generation log, and source/<sha256> blobs that cannot be reconstructed from the
matching checkout. Keep revision checkpoints and
predecessor-correction.json: some historical predecessor generations did not run the
candidate after imperfect predecessor ends and are not physical plant-up evidence.
Reserved episode allocations stay charged; never reset the budget or CMA state.

Stopped at the owner's checkpoint-and-stop request:
  Warrior:22,464/34,560 charged;12,096 remain; strength-3, generation13.
    Forfeited allocations by stage index:0=96,3=96,7=96.
  Rogue:10,848/34,560 charged;23,712 remain; predecessor, generation31.
    Forfeited allocations by stage index:1=96,2=192.
Each final stop forfeits one allocated in-flight96-episode generation; the exact
pre-stop checkpoint and a revision entry are retained. These are charged allocations,
not claims that every forfeited episode physically completed. Both completed flags
remain false. Best saved reached count is0/8 throughout; invalid predecessor
generations are separately documented and cannot support a controller conclusion.

The candidate everyday bed stops at159/324 completed rows, with0 hand-backs. Its
two in-flight jobs were not saved; remaining jobs were not launched. The queued
validation commands were cancelled. The partial .jsonl and exact .meta.json survive;
there is no completed candidate report and no paired comparison claim.

The snapshot materializer first tries matching repository files (including exact
LF/CRLF reconstruction for text), then archived blobs; every result must match its
recorded SHA-256. Large unchanged vendored files need not be duplicated in the archive.
It validates every recorded blob and path before writing a
separate runtime. It refuses mismatched existing files and checks the surrounding
checkout's package-lock. It does not modify production source or the checkpoint.
It prints the exact resume command, with the current allocation remaining. For example,
after the source artifacts have been moved here under rising:

node research/runs/2026-10-13-wrap-up/resume-snapshot.mjs --checkpoint research/runs/2026-10-13-wrap-up/rising/warrior.json
node research/runs/2026-10-13-wrap-up/resume-snapshot.mjs --checkpoint research/runs/2026-10-13-wrap-up/rising/rogue.json

Follow each printed Set-Location and node command separately. Bare dependencies resolve
from the surrounding checkout's node_modules. Every remaining stage uses the pinned
recorded runtime. This is intentional: a direct --resume from a changed checkout is
rejected, and changing line endings alone can otherwise change raw source hashes.

Completed search allocation is not completion of the stand-up plan. The next physical
check after both fixed budgets finish is 16 front and 16 fours starts per body, Balance 0,
standing within 6 s and surviving 2 s. The bar is 12/16 in each posture on each body.
All 64 intended seed1-16 geometries pass clearance; Rogue fours uses the technique's
brace anatomical posture, not a later waypoint. Do not declare a stall before this check.

The saved unassisted target has 0/64 verified successes, all four groups 0/16, capped
median30 s, Balance0/Grit0, zero assist impulses. This is a failure, not anatomical proof.
The support-recovery everyday reference has8/324 completions (8/139 actual takeovers,
175 no-takeover shoves,10 rejected drops); none finish within12 s.

Validation seeds7-12 were not launched. Once continuing work is authorized, run both
stand-up and support-recovery on those same seeds; preserve each run's exact metadata.
The ordinary bed uses the three humanoids, empty hands/right-hand club, eight shove
directions plus dropped starts. Do not substitute this bed for the separate64-fall target.

The mirror directory contains unapplied experimental plant/sit/post mirrored code and a
research side selector. Preserve current native trajectories when integrating it; test
mirrors physically before offering additional sides. The registry remains experimental.
No new recovery defaults, Crypt fall rule, or nonzero character Grit/Balance is qualified.

Packaging: from the checkout root, run
$risingTracked = @{commit=(git rev-parse HEAD);files=@(git ls-files)}
$risingTracked | ConvertTo-Json -Depth 3 | Set-Content research/runs/2026-10-13-wrap-up/tracked-source.json
node research/runs/2026-10-13-wrap-up/portable-manifest.mjs
portable-manifest.json names every data file plus the historical source blobs needed
in rising/. Unchanged committed files, including vendor archives, reconstruct the
other hashes and should not be duplicated in the zip. Keep the named repository
commit, this README, and both utility scripts with the portable archive.
Both active checkpoint implementations are fully reconstructable and hash-validated.
Some historical baseline/revision source bytes are unavailable: the manifest lists
each missingHistoricalSources hash, source path and referring record. Preserve those
historical results and exact hashes, but do not claim fully archived exact replay of
the historical baseline. Missing historical bytes never relax active resume validation.

The plan remains docs/plans/2026-10-13-stand-up.md. Its conditional help requires a stall
report, Grit infrastructure and phase-specific evidence, surge before a constrained root
push, and the owner's decision on nonzero character values. Failed numerical searches
and saturation alone do not establish necessary strength or a sufficient surge factor.

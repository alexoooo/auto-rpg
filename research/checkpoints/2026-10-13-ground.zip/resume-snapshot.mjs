/** Materialize an exact recorded runtime without overwriting the repository's current source. */
import { readFile, writeFile, mkdir, access, lstat } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve, dirname, join, basename, isAbsolute, sep } from "node:path";

const digest = bytes => createHash("sha256").update(bytes).digest("hex");
const quote = value => `'${value.replaceAll("'", "''")}'`;
const options = { checkpoint: null, archive: null, runtime: null, workers: 4 };
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i], value = process.argv[i + 1];
  if (!value || !["--checkpoint", "--archive", "--runtime", "--workers"].includes(key))
    throw new Error("usage: node resume-snapshot.mjs --checkpoint <search.json> [--archive <rising-directory>] [--runtime <new-directory>] [--workers 4]");
  options[key.slice(2)] = key === "--workers" ? Number(value) : value;
}
if (!options.checkpoint || !Number.isSafeInteger(options.workers) || options.workers < 1) throw new Error("checkpoint and positive integer workers are required");
const checkpoint = resolve(options.checkpoint), archive = resolve(options.archive ?? dirname(checkpoint));
const runtime = resolve(options.runtime ?? join(archive, "runtime", basename(checkpoint, ".json")));
const record = JSON.parse(await readFile(checkpoint, "utf8"));
if (!["workshop-fighter", "workshop-rogue"].includes(record.model) || !Number.isSafeInteger(record.stage)
  || !Number.isSafeInteger(record.episodes) || record.episodes < 0 || record.budget !== 34560
  || record.episodes > record.budget || !record.implementation || typeof record.implementation !== "object")
  throw new Error("invalid rising-search checkpoint");
if (record.completed) { console.log("Search is complete; no search resume is required. The separate stall bar and remaining beds are not implied complete."); process.exit(0); }
const manifest = Object.entries(record.implementation), files = [];
// Bare imports resolve through this surrounding checkout's node_modules.
let repository = dirname(runtime);
for (;;) {
  try { await access(join(repository, "package.json")); await access(join(repository, "node_modules", "typescript", "package.json")); break; }
  catch { const parent = dirname(repository); if (parent === repository) throw new Error("place the runtime inside the matching checkout and run npm ci there first"); repository = parent; }
}
if (!runtime.startsWith(repository + sep)) throw new Error("runtime must be a separate directory inside the repository");
const safeChild = async path => {
  if (!path.startsWith(repository + sep)) throw new Error(`path escapes repository: ${path}`);
  const components = path.slice(repository.length + 1).split(sep); let current = repository;
  for (const part of components) {
    current = join(current, part);
    try { if ((await lstat(current)).isSymbolicLink()) throw new Error(`symbolic link in output path: ${current}`); }
    catch (error) { if (error.code === "ENOENT") return; throw error; }
  }
};
await safeChild(runtime);
for (const required of ["research/rising-search.mjs", "research/rising-search-worker.mjs", "research/rising-technique.mjs", "package-lock.json"])
  if (!Object.hasOwn(record.implementation, required)) throw new Error(`runtime manifest lacks ${required}`);
for (const [relative, expected] of manifest) {
  if (!relative || isAbsolute(relative) || /[\\:]/.test(relative) || relative.split("/").some(part => !part || part === "." || part === "..")
    || typeof expected !== "string" || !/^[0-9a-f]{64}$/.test(expected)) throw new Error(`invalid manifest entry ${relative}`);
  const path = resolve(runtime, relative);
  if (!path.startsWith(runtime + sep)) throw new Error(`manifest path escapes runtime: ${relative}`);
  let bytes;
  try {
    const current = await readFile(join(repository, relative));
    if (digest(current) === expected) bytes = current;
    else if (/\.(ts|mjs|js|json)$/.test(relative)) {
      const lf = current.toString().replaceAll("\r\n", "\n");
      for (const variant of [Buffer.from(lf), Buffer.from(lf.replaceAll("\n", "\r\n"))])
        if (digest(variant) === expected) { bytes = variant; break; }
    }
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  bytes ??= await readFile(join(archive, "source", expected));
  if (digest(bytes) !== expected) throw new Error(`source hash mismatch: ${relative}`);
  files.push({ relative, path, bytes, expected });
}

const installedLock = JSON.parse(await readFile(join(repository, "package-lock.json"), "utf8"));
const recordedLock = JSON.parse(files.find(file => file.relative === "package-lock.json").bytes.toString());
if (JSON.stringify(installedLock) !== JSON.stringify(recordedLock)) throw new Error("surrounding checkout's package-lock differs from the recorded runtime; restore that lock and run npm ci before resuming");

// Refuse an existing directory containing a different version of any recorded file.
for (const file of files) {
  await safeChild(file.path);
  try { const existing = await readFile(file.path); if (digest(existing) !== file.expected) throw new Error(`existing runtime differs: ${file.path}`); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
}
for (const file of files) {
  await mkdir(dirname(file.path), { recursive: true });
  try { await writeFile(file.path, file.bytes, { flag: "wx" }); }
  catch (error) { if (error.code !== "EEXIST") throw error; }
  if (digest(await readFile(file.path)) !== file.expected) throw new Error(`materialized hash mismatch: ${file.relative}`);
}
console.log(`Validated ${files.length} source/data blobs. Remaining charged allocation: ${record.budget - record.episodes}.`);
console.log("All remaining stages use this recorded source snapshot; no source from the live working tree is substituted.");
console.log("Run these PowerShell commands after stopping any other process writing this checkpoint:");
console.log(`Set-Location -LiteralPath ${quote(runtime)}`);
console.log(`node research/rising-search.mjs --model ${record.model} --workers ${options.workers} --out ${quote(checkpoint.replace(/\.json$/, ""))} --resume`);

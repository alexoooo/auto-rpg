/** Real ground ownership on the Node stand, Rapier, 120 Hz; locomotion and contacts remain physical. */
import test from 'node:test';
import { getAway } from './.feedback-getaway-candidate16.ts';
import assert from 'node:assert/strict';
import { Quaternion, Vector3 } from '@babylonjs/core/Maths/math.vector.js';
import { coreStand, saveStand, loadStand } from '../../../tests/harness/core-stand.mjs';
import { shows } from '../../../tests/harness/fork.mjs';
import { modelSpec } from '../../../src/core/models.ts';
import { uprightness } from '../../../src/core/control/ground.ts';
import { GUARD } from '../../../src/core/skills/guard.ts';
import { createBody } from '../../../src/core/body.ts';
import { subMindsOf } from '../../../src/core/mind/sub-minds.ts';
import { createSenses } from '../../../src/core/mind/senses.ts';
import { buildBody } from '../../../src/core/build/build-body.ts';
import { dummySpec } from '../../../src/lab/targets.ts';

async function fixture(config, at = [.12, .35, -.25]) {
  const spec = modelSpec('workshop-fighter'), rotation = Quaternion.RotationAxis(Vector3.Right(), -Math.PI / 2).asArray();
  const initial = await coreStand(spec, { posture: GUARD, rotation });
  const height = .02 - uprightness(initial.built).lowest(); initial.dispose();
  const stand = await coreStand(spec, { posture: GUARD, rotation, position: [0, height, 0] });
  const hub = createSenses(stand.world), senses = hub.add({ id: 'own', side: 'a', built: stand.built, out: () => false });
  let target;
  const moveFoe = position => {
    if (target) { hub.remove('foe'); target.dispose(); }
    target = buildBody(dummySpec(spec), stand.world, { position });
    for (const part of target.segments.values()) part.body.setFixed(true);
    hub.add({ id: 'foe', side: 'b', built: target, out: () => false });
  };
  moveFoe(at);
  const body = createBody(stand.built, stand.world, { feedback: true, senses,
    subs: [(own, view) => getAway(own, view, config), ...subMindsOf([{ kind: 'stand-up', techniques: ['roll', 'roll-back', 'plant-up', 'sit-up', 'post-up'] }])],
    contactIdentity: other => [...target.segments.values()].some(part => part.body === other)
      ? { kind: 'body', body: 'foe', segment: 'head', guard: false } : null });
  return { ...stand, body, hub, moveFoe, states: { body: body.state, senses: hub.state },
    dispose() { body.dispose(); hub.dispose(); target.dispose(); stand.dispose(); } };
}

test('scratch escape separates from the real foe and yields to actual StandUp', async () => {
  const f = await fixture({kind:'get-away',metres:2}, [1,.3,-.9]);
  try {
    let handoff=null, escaping=false;
    for(let step=0;step<3000;step++) {
      f.step();
      if(f.body.has==='Get away') escaping=true;
      if(escaping && f.body.has.startsWith('stand up:')) {handoff={time:f.world.time,metres:f.body.state.mind.subs[0].metres,state:structuredClone(f.body.state.mind.subs[0]),owner:f.body.has};break;}
    }
    assert.ok(handoff, JSON.stringify(f.body.state.mind.subs[0]));
    assert.ok(handoff.metres>=2.5,JSON.stringify(handoff));
    assert.equal(handoff.state.active,false);
    assert.equal(handoff.state.running,null);
    assert.equal(handoff.state.holding,false);
    console.log(JSON.stringify(handoff));
  } finally {f.dispose();}
});
